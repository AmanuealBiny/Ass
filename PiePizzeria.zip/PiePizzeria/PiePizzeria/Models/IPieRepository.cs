﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PiePizzeria.Models
{
    public interface IPieRepository
    {

        // this is contract for Models this will have two propertiys 

        IEnumerable<Pie> GetAllPies();
        Pie GetPieById(int pieId);
    }
    // create an instant of 
}
