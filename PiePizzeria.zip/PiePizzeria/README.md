# PiePizzeria
This Assignment is designed for crating an empty pizza cafteria menus
*** steps to create empty project following the following 7steps

1. create the model
2. Creating (and Implementing) the repository
3. registering the service (for D.I)
4. creating the Controller
5. adding the view
6. Introducing View Modules
7. Styling the views

